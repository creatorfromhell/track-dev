<?php
/**
 * Created by Daniel Vidmar.
 * Date: 5/17/14
 * Time: 1:40 AM
 * Version: Beta 1
 * Last Modified: 5/17/14 at 1:40 AM
 * Last Modified by Daniel Vidmar.
 */
if(isset($_POST['add'])) {

}

if(isset($_POST['edit'])) {

}